//// toggle navbar menu
const navbarMenu = document.querySelector(".navbar-menu");
const navbarToggler = document.querySelector(".navbar-menu-toggle button");

navbarToggler.onclick = function () {
    navbarMenu.classList.toggle("show");
    navbarToggler.classList.toggle("close");
};

/// change between tabs
const tabsHeader = document.querySelector(".tabs--header");
const tabWhoWeAre = document.getElementById("tab-who-we-are");
const tabOurVision = document.getElementById("tab-our-vision");
const tabOurHistory = document.getElementById("tab-our-history");

tabsHeader.addEventListener("click", (e) => {
    if (e.target !== tabsHeader) {
        for (let el of tabsHeader.children) el.classList.remove("active");
        e.target.classList.add("active");

        tabWhoWeAre.classList.remove("active");
        tabOurVision.classList.remove("active");
        tabOurHistory.classList.remove("active");

        switch (e.target.dataset.tab) {
            case "who-we-are":
                tabWhoWeAre.classList.add("active");
                break;
            case "our-vision":
                tabOurVision.classList.add("active");
                break;
            case "our-history":
                tabOurHistory.classList.add("active");
                break;
        }
    }
});

//// show and hide back to top arrow
const backToTop = document.querySelector(".scroll-top");

window.onscroll = function () {
    if (
        document.body.scrollTop > 50 ||
        document.documentElement.scrollTop > 50
    ) {
        backToTop.style.display = "flex";
    } else {
        backToTop.style.display = "none";
    }
};

backToTop.addEventListener("click", () => {
    window.scrollTo(0, 0);
});

/// active menu section
const navbarLinks = document.querySelectorAll(".navbar-link");

function onScroll(e) {
    const scrollPos =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

    for (let i = 0; i < navbarLinks.length; i++) {
        let currentLink = navbarLinks[i];
        let currentSection = document.querySelector(
            currentLink.getAttribute("href")
        );
        let scrollTopMinus = scrollPos + 70;
        if (
            currentSection.offsetTop <= scrollTopMinus &&
            currentSection.offsetTop + currentSection.offsetHeight >
                scrollTopMinus
        ) {
            document.querySelector(".navbar-link").classList.remove("active");
            currentLink.classList.add("active");
        } else {
            currentLink.classList.remove("active");
        }
    }
}

window.document.addEventListener("scroll", (e) => onScroll(e));

navbarLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        document.querySelector(link.getAttribute("href")).scrollIntoView({
            behavior: "smooth",
        });
    });
});
